Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("ACCOUNT_CHOOSER=AFx_qI6EPYYcLxF7n9kNBQ4CKRB5sFNXNckGejTCnFDc_2VFHda6CEFkgLgT3J7Q1qwC1LrFtPxHSnYidUcS7ZdS8mZD3mmodnW9ZOMr86DpqUhEdFPH5SJb-5-7AVuyQ3Lc1SZ8vgnSS3ksXs99XrNEO5z0bfPpFw; DOMAIN=accounts.google.com");

	web_add_cookie("HSID=A5NQHtmR-qvmfCUBR; DOMAIN=accounts.google.com");

	web_add_cookie("SSID=AiQYD1Y-f3LwRvRsF; DOMAIN=accounts.google.com");

	web_add_cookie("APISID=c1giSayrYk9ckh_J/AU_u-OevbAC_c_S6s; DOMAIN=accounts.google.com");

	web_add_cookie("SAPISID=vYgnxAxOcgArFfSU/AuOIEHjwrtoduNnmD; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PAPISID=vYgnxAxOcgArFfSU/AuOIEHjwrtoduNnmD; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PAPISID=vYgnxAxOcgArFfSU/AuOIEHjwrtoduNnmD; DOMAIN=accounts.google.com");

	web_add_cookie("SEARCH_SAMESITE=CgQIm54B; DOMAIN=accounts.google.com");

	web_add_cookie("SID=g.a000zAhTgysp9-YuFh36BNCtbUViW3JesNXmzCZeNZwH9WHZBk5xEn9TC4nCFSJ_oDk67dQ4pAACgYKAdkSARESFQHGX2MiIRa3yeAkjiMVeFXKrZ-UhhoVAUF8yKojBvcqyJamPEthPXdB8MPw0076; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PSID=g.a000zAhTgysp9-YuFh36BNCtbUViW3JesNXmzCZeNZwH9WHZBk5xh8t4DjTuA-HjDPjOw0cdeAACgYKAUESARESFQHGX2MiD9kr1T9qdMHLOQSf-7jWDhoVAUF8yKqfUTYyo95F5FoCgaV3u6sx0076; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSID=g.a000zAhTgysp9-YuFh36BNCtbUViW3JesNXmzCZeNZwH9WHZBk5x4PI1-1FzMa0-l-NvfJ2UegACgYKAeESARESFQHGX2MiLPziYF7twmjrLEbW_m6NhxoVAUF8yKo2GXr0mCa-dglXY0xTHKG40076; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-ENID=28.SE=L7XXhCRO1u17EG_UR8qRbjJPelv--66mtdIfy2Oc2nn-b96_8HcsGjfrbrbZuI5tVfPpvDKfB8uezbdjZDsUpoxMzp1BQr_5kFAuRl3rOFAqLV4Chi1I50M89g4xRLejTLeMXTXaLhg_5CI-als47H-3-rEO3y8nUHodfZyBpe1j-iinKrisqydHL2Q8IlkOmV0UBgrbNufObWVahkp8O8vxMQeKFNXLxM9Z77Kk5EjXH1_KyTbN4n2ICcnWwNp5HvXKcovWmAVbMJU4VbDY3yMyWycqgmA4XzHDmQ-IDOiOh4u8caAUQAoprJ8ITpwNIz2vZ5fe3aWyx-Wc9uXpGHPL6NtG8uo; DOMAIN=accounts.google.com");

	web_add_cookie("OTZ=8185860_34_34__34_; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-GAPS=1:AbRbp8OzI2UXrkRTbaKIn8opzfaSEFXViYveN5-xZoXeFck1m_tCo6bLazaIsfKOVGGmDIy0wWBAPypH_3FxSCuQeXjxkA:XCZkbbtVOPPU-5YV; DOMAIN=accounts.google.com");

	web_add_cookie("LSID=o.calendar.google.com|o.chromewebstore.google.com|o.drive.google.com|o.drive.usercontent.google.com|o.mail.google.com|o.meet.google.com|s.IN|s.youtube:g.a000zQhTg5dopzMwMn-yaXmPXeorv2JVvhNUZarQ-Zobp8avmOOeoeP4xhZ0LTeUcRMaCvCAXQACgYKAeYSARESFQHGX2Miv2tY1cII7MbVNOH9fThfhxoVAUF8yKptJsySYMXClpYU3Nq6jt3B0076; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-1PLSID=o.calendar.google.com|o.chromewebstore.google.com|o.drive.google.com|o.drive.usercontent.google.com|o.mail.google.com|o.meet.google.com|s.IN|s.youtube:g.a000zQhTg5dopzMwMn-yaXmPXeorv2JVvhNUZarQ-Zobp8avmOOeE7KSpG-tQo1e1neoTSDh-gACgYKAXISARESFQHGX2MiRBcDi5dXEHzOp-J_b-JcVRoVAUF8yKq8KM6364-9iMrZtaEokv_Q0076; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-3PLSID=o.calendar.google.com|o.chromewebstore.google.com|o.drive.google.com|o.drive.usercontent.google.com|o.mail.google.com|o.meet.google.com|s.IN|s.youtube:g.a000zQhTg5dopzMwMn-yaXmPXeorv2JVvhNUZarQ-Zobp8avmOOeZNXxemworgcbW-ePG7uSeQACgYKAY4SARESFQHGX2Mi5BSVLl6XzVzjCPTO95yV7xoVAUF8yKpQkfLQ3l_KLp7yB1OHWfrP0076; DOMAIN=accounts.google.com");

	web_add_cookie("AEC=AVh_V2i1Xd1C3u4ugkw9SFBIAZB-SHOYW8NvjmPM3FxK3TU0cv5knenmaVc; DOMAIN=accounts.google.com");

	web_add_cookie("NID=525=euR22nd47roqWHkj-mxrOlB_XiaDnwcYkM1TrzdtUj0BFZG8ZgnIYoiQF8tUD_hjnfhCg0Y3omjY9yg3jL4vM0K9ly8capkE6odkeXQtkYGq_sVPAk_iUqX2ykXyEbxx47LAEuFpWcvRWL9w9e93MFBunYUDPTyjx2ozjGCRYJPNThNq3ztW-VxczwtMhUcevZmd4zZbLnhhmCn0GeCNsH03KRdHXE0YLxsjQO0FbfLfvW1tLN-nJwEieRp_Q95gTC05Z2dYIT6cv2B92OxgUsYl6Qhge3UiOQbwowHb0fx1og1l4A1JEx-aRkeT3Qh2rHyVxDeqwCu-bnQL4eipmuzrlD1A0b9-SI0; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PSIDTS=sidts-CjIB5H03Px03vLyL3s505izC4oMaroy9QWayaqS1dPlkfGjJkZwzGnaBk8XaqXLNwSEt1RAA; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSIDTS=sidts-CjIB5H03Px03vLyL3s505izC4oMaroy9QWayaqS1dPlkfGjJkZwzGnaBk8XaqXLNwSEt1RAA; DOMAIN=accounts.google.com");

	web_add_cookie("SIDCC=AKEyXzVtakp6pTiMF-2-9jkfP1-UG0NvDGWx4Iw0pob45SZhVhqRpSFFp97G9xzvvBwrXvkQplE; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PSIDCC=AKEyXzWIlIjMxt4EMWiX4kOGznFO6OIYYuHsvbBSN6ksvVqReczx7D5CHOHIATLLLKKtnjcAqhI; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSIDCC=AKEyXzXwgy2TpcXVx0EkAIMhmqda1uirDq5J85mFMxwenuo0_cA2995w8KNOngVyOST6tBM0DQ; DOMAIN=accounts.google.com");

	web_add_header("Origin", 
		"https://www.google.com");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&laf=b64bin&json=standard", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/binary", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		"Body= ", 
		LAST);

	web_add_header("A-IM", 
		"x-bm,gzip");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=139", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\"Not;A=Brand\";v=\"99\", \"Google Chrome\";v=\"139\", \"Chromium\";v=\"139\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("jpetstore.aspectran.com", 
		"URL=https://jpetstore.aspectran.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/cdn-cgi/speculation", ENDITEM, 
		"Url=/css/jpetstore.css?20250227", ENDITEM, 
		"Url=https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,400;0,700;1,400&display=swap", ENDITEM, 
		"Url=https://cdn.jsdelivr.net/gh/aspectran/aspectran-assets/app/webroot/assets/js/modernizr-custom.js", ENDITEM, 
		"Url=https://cdn.jsdelivr.net/gh/aspectran/aspectran-assets/app/webroot/assets/foundation@6.9.0/css/aspectran.css", ENDITEM, 
		"Url=/images/logo-topbar.gif", ENDITEM, 
		"Url=https://code.jquery.com/jquery-3.7.1.min.js", ENDITEM, 
		"Url=/images/cart.gif", ENDITEM, 
		"Url=https://unpkg.com/htmx.org@2.0.4/dist/htmx.min.js", ENDITEM, 
		"Url=/images/splash.gif", ENDITEM, 
		"Url=https://cdn.jsdelivr.net/gh/aspectran/aspectran-assets/app/webroot/assets/img/aspectran-site-logo.png", ENDITEM, 
		"Url=https://cdn.jsdelivr.net/gh/aspectran/aspectran-assets/app/webroot/assets/foundation@6.9.0/js/foundation.min.js", ENDITEM, 
		"Url=https://petclinic.aspectran.com/images/pets.png", ENDITEM, 
		"Url=https://cdn.jsdelivr.net/gh/aspectran/aspectran-assets/app/webroot/assets/img/aspectran-logo-grey-x100.png", ENDITEM, 
		"Url=https://cdn.jsdelivr.net/gh/aspectran/aspectran-assets/app/webroot/assets/img/favicon-32x32.png", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("X-Client-Data", 
		"CIi2yQEIo7bJAQipncoBCKOIywEIlaHLAQiko8sBCIWgzQEImvzOAQi6/c4BCOuAzwEIlIHPAQiEhM8BGOHizgE=");

	web_custom_request("v1_GetModels", 
		"URL=https://optimizationguide-pa.googleapis.com/v1_GetModels?key=AIzaSyA2KlwBX3mkFo30om9LUFYQhpqLoa_BNhE", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/x-protobuf", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=application/x-protobuf", 
		"BodyBinary=\n\\x04\\x08\\x02 \\x14\nn\\x08\t \\x142h\natype.googleapis.com/google.privacy.webpermissionpredictions.v1.WebPermissionPredictionsClientInfo\\x12\\x03\\x08\\x8B\\x01\n\\x04\\x08\r \\x14\ne\\x08\\x0F \\x142_\nWtype.googleapis.com/google.internal.chrome.optimizationguide.v1.PageTopicsModelMetadata\\x12\\x04\\x08\\x020\\x02\ng\\x08\\x10 \\x142a\nYtype.googleapis.com/google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\nn\\x08\\x14 \\x142h\n"
		"atype.googleapis.com/google.privacy.webpermissionpredictions.v1.WebPermissionPredictionsClientInfo\\x12\\x03\\x08\\x8B\\x01\ng\\x08\\x15 \\x142a\nYtype.googleapis.com/google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\ng\\x08\\x17 \\x142a\nYtype.googleapis.com/google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\n\\x04\\x08\\x18 \\x14\n\\x04\\x08\\x19 \\x14\nl\\x08\\x1A \\x142f\n`type.googleapis.com/"
		"google.internal.chrome.optimizationguide.v1.AutocompleteScoringModelMetadata\\x12\\x02\\x10\\x02\ng\\x08\\x1B \\x142a\nYtype.googleapis.com/google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\ng\\x08- \\x142a\nYtype.googleapis.com/google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\ng\\x08. \\x142a\nYtype.googleapis.com/"
		"google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\\x18\\x06*\\x05en-GB2\\x02\\x08\\x06", 
		LAST);

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_custom_request("token", 
		"URL=https://www.googleapis.com/oauth2/v4/token", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"Body=client_id=77185425430.apps.googleusercontent.com&client_secret=OTJgUOQcT7lO7GsGZq2G4IlT&grant_type=refresh_token&refresh_token=1//0cFXmSzHDZ2cOCgYIARAAGAwSNwF-L9IrNPofmR6rb2nucuQ8k5jj_S_VgagqGN_sjPPR7hDLuRjRIOqn37OpP9THwfjdNDt4GeQ&scope=https://www.googleapis.com/auth/chromesync", 
		LAST);

	lr_start_transaction("Launch");

	web_add_header("X-Chrome-UMA-Log-SHA1", 
		"4F64810A08D49F2A7B09740CCCF9C311AE21755E");

	web_add_header("X-Chrome-UMA-Log-HMAC-SHA256", 
		"rA1Oys23xhTVsx57jkVfFk4WjDI3J8RgOtQPXuoLSI8=");

	web_add_auto_header("X-Chrome-UMA-ReportingInfo", 
		"CAE=");

	lr_think_time(39);

	web_custom_request("v2", 
		"URL=https://clientservices.googleapis.com/uma/v2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/vnd.chrome.uma", 
		"BodyBinary=\t\\x88x\\xE8\\xA7\\x8Ck\\xD0\\xB0\\x10\\xE3\\x08\\x1A\\xCA\\x1C\\x08\\xC2\\xA1\\xA5\\xC4\\x06\\x12\\x10139.0.7258.66-64\\x18\\xD0\\x8A\\xBE\\xB0\\x06\"\\x05en-GB*\\x18\n\nWindows NT\\x12\n10.0.261002\\x9F\\x02\n\\x06x86_64\\x10\\x87\\x7F\\x18\\x80\\x80\\xAC\\x97\\x90\\xFF\\x1F\"\\x11HP ProBook 440 G6(\\x010\\x80\n8\\xD0\\x05B\\x90\\x01\\x08\\x86\\x81\\x02\\x10\\xA0}\\x1A\r31.0.101.21352\\x13Google Inc. (Intel):cANGLE (Intel, Intel(R) UHD Graphics 620 (0x00003EA0) Direct3D11 vs_5_0 "
		"ps_5_0, D3D11-31.0.101.2135)MC\\xD3\\x1DCU\\xB9\\xA7\\x1DCe\\x00\\x00\\xC0?j\\x18\n\\x0CGenuineIntel\\x10\\xEC\\x8D \\x18\\x08 \\x01(\\x00\\x82\\x01\\x02\\x08\\x00\\x8A\\x01\\x02\\x08\\x00\\xAA\\x01\\x06x86_64\\xB0\\x01\\x01\\xCA\\x01\\x1C\n\\x02HP\\x12\\x048537\\x1A\\x02HP\"\nHPQOEM - 0(\\x02J\n\r\\x8A\\xBC'o\\x15\\xF3\\x0C&|J\n\rd\\xBDm\\xA6\\x15\\x80\\x8D}\\xCAJ\n\rv+\\xAB\\x04\\x15\\x80\\x8D}\\xCAJ\n\r{\\xDC\\xB0\\xEF\\x15\\x80\\x8D}\\xCAJ\n\r\\x1BX\\xED9\\x15sY\\x8C\\x1FJ\n\r\\xA3&%\r"
		"\\x15Z\\xE5{7J\n\r\\xF5\\xB5\\xE5\\xA1\\x15\\x80\\x8D}\\xCAJ\n\rX\\xDF>\\xF7\\x15Z\\xE5{7J\n\r'M*\\xE9\\x15\\x80\\x8D}\\xCAJ\n\r\\x11\\xEF#B\\x15\\x80\\x8D}\\xCAJ\n\r\\xC2\\xF5\\xFE\\xE9\\x15Z\\xE5{7J\n\r \\xC6\\xC5\\x99\\x15sY\\x8C\\x1FJ\n\r\\x14\\xFE\\x82\\x83\\x15\\x80\\x8D}\\xCAJ\n\rVT\\x16\\x9D\\x15\\x80\\x8D}\\xCAJ\n\r\\xF4wN\\xF6\\x15\\xC8\\xA3k\\xB0J\n\r\\x10\\x0C\\xF8\\x08\\x15\\x93I\\x17;J\n\r.\\x05,\\xA6\\x15\\x80\\x8D}\\xCAJ\n\r\\x90@}k\\x15\\x80\\x8D}\\xCAJ\n\r+"
		"\\x18\\xCC\\xFA\\x15S.\\xA6\\xFEJ\n\r\\xA2\\x15=\\x00\\x154\\xEB\\xD25J\n\r\\xA2ve\\xC6\\x15\\xD6J\\x06\\x18J\n\r\\x95\\xAA\\x950\\x15\\xDF\\x17J?J\n\r\\xF3\\xED\\xC1=\\x15\\x80\\x8D}\\xCAJ\n\rE\\xDA\\x92\\xFB\\x15\\xAC\\xEE;\\xF3J\n\r\\xC4E\\xA5\\xE0\\x15\\xA7\\xEC\\x9D%J\n\r\\x81\\x03\\x98\\xB3\\x15\\xA5\\xEB\\xC33J\n\r\\xAC\\x00\\x1C.\\x15\\xB6\\xBA-\\x8BJ\n\rqS\\x03X\\x15\\x80\\x8D}\\xCAJ\n\r\\x83*5y\\x15\\x80\\x8D}\\xCAJ\n\rTr\\xF6,\\x15Z\\xE5{7J\n\r4\\x82+\\x83\\x15\\x80\\x8D}\\xCAJ\n\r"
		"\\xD3\\x0E\\x99)\\x15\\xC7\\x92\\xDCnJ\n\r0&(g\\x15\\xA1\\x9A\\xE0\\xFEJ\n\r\\xFEX\\xFF\\xFD\\x15\\x80\\x8D}\\xCAJ\n\r3\\x14\\xECG\\x15$=\\x08\\xCBJ\n\r\\xFEV-J\\x15Z\\xE5{7J\n\rC\\xEB3Q\\x15u\\x00>\\x0CJ\n\r\\xB9\\xF5\\x14\\xF3\\x15 i?\\x8FJ\n\r\\xD8\\xEA0\\x0E\\x15\\xF3\\xF6L\\xB1J\n\r\\xA3\\xEE\\x1A\\x7F\\x15\\x80\\x8D}\\xCAJ\n\r\n\\x1E\\xB0.\\x15\\xCA%\\xE8^J\n\r\\x98\\xDC\\xBA\\xDB\\x15\\xCC\\x99\\x84wJ\n\r\\x01\\xA4\\xA2\\x7F\\x15\\x80\\x8D}\\xCAJ\n\rD^\\x8AW\\x15\\x80\\x8D}\\xCAJ\n\r"
		"\\xDE\\x90\\x17\\xFC\\x15\\x80\\x8D}\\xCAJ\n\r\\xF8s\\xF2+\\x15Z\\xE5{7J\n\rB\\xC5\\xF5\\xF6\\x15\\x80\\x8D}\\xCAJ\n\r\\x93\\xBEy7\\x15\\x1B;D\\xB0J\n\r\\x07[x\\xDE\\x15\\x80\\x8D}\\xCAJ\n\re.+\\xF3\\x15\\x80\\x8D}\\xCAJ\n\r\\xAD\\xD6\\xE9\\x08\\x15\\x80\\x8D}\\xCAJ\n\r\\xAAaZ\\x1B\\x15\\x80\\x8D}\\xCAJ\n\r\\xB8\\xA1\\x82\\xA5\\x15=\\xF4\\xD3ZJ\n\r\\x990\\xCE\\xD7\\x15\\x80\\x8D}\\xCAJ\n\rH\\x96\\xF1\\xCA\\x15)\\xB9\\xDA\\x10J\n\rp\\xD1m\\xBD\\x15\\x80\\x8D}\\xCAJ\n\ra"
		"<\\x12m\\x15\\xDB\\xF9f\\x07J\n\r\\xC8\\x99\\xF4h\\x15\\x80\\x8D}\\xCAJ\n\r\\xEB\\x89\\\\\\xA0\\x15\\x80\\x8D}\\xCAJ\n\r\\xFD\\x8F1\\x0B\\x15\\x80\\x8D}\\xCAJ\n\rFKh\\x87\\x15\\x80\\x8D}\\xCAJ\n\r\\xD9\\x89\\xA7\\xCB\\x15\\x80\\x8D}\\xCAJ\n\r@N\\xB84\\x15\rOb\\x95J\n\r\\xD9/g>\\x15\\x80\\x8D}\\xCAJ\n\r\\xA6\\xF4vP\\x15\\x037\\xA4\\xF9J\n\r\\xC2\\x84\\xF6B\\x15Z\\xE5{7J\n\r!\\xEA,\\xBF\\x15\\x80\\x8D}\\xCAJ\n\r\\x01$\\xCF\n\\x15\\x80\\x8D}\\xCAJ\n\r\\xD3\\x10\\x88\\xEF\\x15\\xA5\\xEB\\xC33J\n\r"
		"#\\xD9=t\\x15\\xCA\\xEEHGJ\n\r\\xE5QJ\\x86\\x15\\x80\\x8D}\\xCAJ\n\r\\x02\\xF5p\\x1F\\x15\\x80\\x8D}\\xCAJ\n\r&\\xCCFA\\x15\\x80\\x8D}\\xCAJ\n\r\\xF60\\xF1\\xD7\\x15Z\\xE5{7J\n\r:\\xEE\\x83\\x16\\x15\\x80\\x8D}\\xCAJ\n\rm#:^\\x15d\\xC4;`J\n\r\\xD9\\xDF=\\xD4\\x15\\xCC5b\\xE3J\n\r\\xA6\\x03\\xBC3\\x15J\\xD4\\x8A\\x02J\n\r~\\x84$\\x7F\\x15\\xA5\\xEB\\xC33J\n\r\\x9F\\xE5\\xDD\\xC7\\x15\\x80\\x8D}\\xCAJ\n\r\\xE3\\xA9\\xB9\\xF7\\x15\\x80\\x8D}\\xCAJ\n\r\\xAE\\xA5\\x00\\xE9\\x15\\x93\\xA4(\\xD4J\n\r"
		"\\x0B\\x10v@\\x15Z\\xE5{7J\n\r\\xBD\\x1E\\xE7w\\x15\\\\L;&J\n\r\\x0C\\xEF\\x8F\\x06\\x15\\x80\\x8D}\\xCAJ\n\r\\xBE:\\x99\\xBB\\x15\"h\\xC9\\xAFJ\n\r\\x0F\\x16I\\xD6\\x15\\x80\\x8D}\\xCAJ\n\r\\xDE\\x92\\x10\\xC5\\x15\\x80\\x8D}\\xCAJ\n\r\\xD1\\xAD\\xF5\\x14\\x15Z\\xE5{7J\n\r\\xFEC\\xB1\\xBC\\x15\\x80\\x8D}\\xCAJ\n\r\\x17\\xB2\\x89r\\x15Z\\xE5{7J\n\rJ\\xBD\\xFF\\xB9\\x15\\x80\\x8D}\\xCAJ\n\r\\xA19f\\xD0\\x15\\x80\\x8D}\\xCAJ\n\r\\xBE/\\xA1Y\\x15\\x19S55J\n\r\\xE7\\xCD\\xE2;\\x15\\xF3\\x0C&|J\n\r"
		"\\x1F~\\xBC\\x85\\x15\\x80\\x8D}\\xCAJ\n\rGS\\xBEZ\\x15*\\xD3\\xB9\\x85J\n\r\\xC2\\x85\\xE2\\x88\\x15\\x80\\x8D}\\xCAJ\n\r\\xB6\\xB1\\xDD\\x17\\x15Z\\xE5{7J\n\r\\x90Y\\xC4l\\x15Z\\xE5{7J\n\rz\\x12.\\xDD\\x15\\x1D\\xB7\\x0F\\xE9J\n\r?\\xA8\\xB7f\\x15\\x80\\x8D}\\xCAJ\n\rk\\xA7!\\xD7\\x15\\x80\\x8D}\\xCAJ\n\rP\"6\\x86\\x15\\xFAY\\xA2\\xA3J\n\r\\xA6\\x03\\xA3N\\x15\\x18]\\x98oJ\n\rn<Y\\x19\\x15\\x80\\x8D}\\xCAJ\n\r\\xE6\\xB8\\xA23\\x15\\x80\\x8D}\\xCAJ\n\r\\xA6x\\xB1\\x82\\x15\\x80\\x8D}\\xCAJ\n\r"
		"D\\xAF\\x92\\xB3\\x15\\x80\\x8D}\\xCAJ\n\r\\x1D)\\xB6\\xF3\\x15<\\xBB\\xB2kJ\n\r\\xF4\\xDD\\xDC\\x1E\\x15\\xD5\\x13\\x9DeJ\n\r\\x1D\\x88\r\\xEA\\x15\\x80\\x8D}\\xCAJ\n\rA\\x90\\xF2\\xB6\\x15\\x80\\x8D}\\xCAJ\n\r\\x9AVY\\x93\\x15\\x80\\x8D}\\xCAJ\n\r\\xF5hC\\xD9\\x15\\x80\\x8D}\\xCAJ\n\r\\x0B\\xD0F\\xC0\\x15\\x80\\x8D}\\xCAJ\n\rI\\x96KD\\x15\\x80\\x8D}\\xCAJ\n\r3Y\\x06X\\x15(\\xA2\\xE0\\xB9J\n\r\\xF0\\xFDt\\xA3\\x15\\x80\\x8D}\\xCAJ\n\rO5\\x03\\xC4\\x15\\x80\\x8D}\\xCAJ\n\r\\xF9\\xCD;"
		"\\xAF\\x15\\xB6\\xB1\\xF4\\xA7J\n\r*\\x9D\\xFAS\\x15\\xB8\\x98\\xF9\\xA7J\n\r\\xB56\\xDF\\xA8\\x15\\x80\\x8D}\\xCAJ\n\r\\xBC\"\\xAF[\\x15Z\\xE5{7J\n\r#\\x05\\xA2R\\x15\\x80\\x8D}\\xCAJ\n\r\\xFD\\x9B\\xC9I\\x15Z\\xE5{7J\n\r\\x1B$\\xC6'\\x15Z\\xE5{7J\n\rz\\xCF\\xD3\\xBA\\x15\\x80\\x8D}\\xCAJ\n\rR\\xF9\\x9Ds\\x15\\x80\\x8D}\\xCAJ\n\rw\\xC8\\xAD1\\x15\\x80\\x8D}\\xCAJ\n\rWM\\x14&\\x15\\x80\\x8D}\\xCAJ\n\rI\\xB7\\x8A>\\x15\\x80\\x8D}\\xCAJ\n\r\\x14\\x03\\x86\\x90\\x15\\xD0H\\xDD\\x02J\n\r`\\x87MI\\x15C"
		"]2RJ\n\rU\\x08\\xC6:\\x15\\x9C*nHJ\n\r\\xD3\\x01\\x8C\\xF4\\x15O\\xE4\\xBA\\xE5J\n\r\\xA3\\xB6\\xDCc\\x15\\xFA\\xFC\\x11\\xF9J\n\rF\\xE7\\x06\\xE7\\x15\\xC8\\xD0(\\xBBJ\n\r\\x0C\\x19\\x96\\xF2\\x15Z/m\\xFDJ\n\r\\xE2\\xAABD\\x15\\x14\\x0F\\xCC\\xE1J\n\rd\\xCF\\x90\\xF6\\x15<\\xB1\\xF6\\xD7J\n\rw\\xD3\\xD1\\x0E\\x15\\x14\\x0F\\xCC\\xE1J\n\r\\xA0\\xF0\\xF0u\\x15\\x14\\x0F\\xCC\\xE1J\n\r\\x90?\\x0Cq\\x15<\\xB1\\xF6\\xD7J\n\r\\x81\\x84\\xB1\\xE2\\x15c(\\x82\\xA5J\n\r"
		"\\x89\\x18\\xE7\\xE7\\x15\\x14\\x0F\\xCC\\xE1J\n\r\\xEDZ\\x19\\x02\\x15\\x96\\xA4\\x94\\xE0J\n\r:\\x97\\xB2\\x14\\x15\\xEER$QJ\n\r|\\xFD\\x0C&\\x15\\xB6\\xC1\\x0B\\x8EJ\n\r\\xC2\\xA9\\xA4\\xBE\\x15\\x80\\x8D}\\xCAJ\n\r\\xC2Fb/\\x15\\x80\\x8D}\\xCAJ\n\r\\xA5\\x19\\xF7t\\x15\\x037\\xA4\\xF9J\n\r(\\xE8\\xE0E\\x15\\x80\\x8D}\\xCAJ\n\r\\x93\\xF2\\xDB\\x1D\\x15\\x80\\x8D}\\xCAJ\n\r}\\xDC\\x92\\x0E\\x15\\x80\\x8D}\\xCAJ\n\rV\\x13\\x04\\xE0\\x15\\xB7\\x9F\\x8D\\xC0J\n\r"
		"\\x92\\xB7W\\xB3\\x150\\xAE\\xF2\\xDCJ\n\r\\x05\\x0E\\xF0\\xF4\\x15\\x80\\x8D}\\xCAJ\n\r\\x98\\xCE\\x81\\x94\\x15\\xDF\\x17J?J\n\r\\x98\\xF6\\x83\\xA9\\x15\\xA1$\\x94|J\n\r\\x03lB*\\x15\\xF4\\xF4G=J\n\r\\x18\\x85gp\\x15njo J\n\r4\\x873\\xBE\\x15\\xB1\\xA5\\x95JJ\n\r\\xA9\\x07\\x99_\\x15njo J\n\r\\x9A\\xCB\\xEC\\x8E\\x15,M\\xC8\\xB5J\n\r\\x83VF+\\x15g\\xAD\\x016J\n\r&y\\xFCR\\x15\\x02\\xFF\\x90\\x17J\n\r\\x1D6\\x9B\\xBC\\x15\\xA8o\\xE6\\xDEJ\n\r\\x88q\\x1A\\xA4\\x15\\xFB\\xAF\\xCFBJ\n\r"
		"\\xDC\\xBFq\\xFF\\x15\\xA8o\\xE6\\xDEJ\n\r\\x0C\\xDDY!\\x15uH\\xABRJ\n\r\\xD5y\\xCC\\xE7\\x15\\xA8o\\xE6\\xDEJ\n\rEU\\x93K\\x15\\xDF\\x17J?J\n\r\\xE3\\xBA8\\x9A\\x15\\xA7\\xC8F`J\n\r\\xE1\\x04\\xADA\\x15@_\\x06\\xE4J\n\r\\xA3C\\x1E-\\x15\\xF4\\xF4G=J\n\rg\\xC2m8\\x15\\xF4\\xF4G=J\n\r}\\x96\\x9D\\xD6\\x15.\\xC9\\x956J\n\r\\xA1u\\x8F<\\x15\\xA5@\\xF8\\xA6J\n\r5k@\\xA4\\x15\\xD6\\xE2W\\x16J\n\r"
		"F\\xA1\\x8D@\\x15\\xD6\\xE2W\\x16P\\x04ZI\\x08\\x01\\x10\\xF1\\xF1\\xC7\\xB1\\x06\\x18\\xF5\\xF1\\xC7\\xB1\\x06\"\\x1A\n\\x0C140.0.7273.0\\x10\\xA4\\x9B\\xB2\\xB1\\x06\\x18\\x00 \\x00(\\x00*\\x1D\n\r139.0.7258.66\\x10\\xF5\\xF1\\xC7\\xB1\\x06\\x18\\x00 \\x1E(\\x80\\x80\\x0Cb\\x04GGLSj\\x08\\x08\\x00\\x10\\x008\\x06@\\x06\\x80\\x01\\xB0\\xD9\\x89\\xA2\\x06\\x90\\x01\t"
		"\\x90\\x01\\x84\\x01\\x90\\x01\\xC4\\x01\\x90\\x01\\x83\\x02\\x90\\x01\\xA3\\x02\\x90\\x01\\xB5\\x02\\x90\\x01\\xBA\\x03\\x90\\x01\\xA0\\x06\\x98\\x01\\x01\\xBA\\x01\\x0C\\x15i\\x04u~%\\x00\\x00\\x00\\x00(\\x00\\xC2\\x01\\x1D\\x08!\\x12\\x0F2025.6.13.84507\\x1D\\x00\\x00\\x00\\x00%\\xD3\"Ac\\xC2\\x01\\x12\\x080\\x12\\x041390\\x1D\\x00\\x00\\x00\\x00%\\x86\\xB3\\xD8|"
		"\\xC2\\x01\\x14\\x08\\x0B\\x12\\x069.58.0\\x1D\\x00\\x00\\x00\\x00%\\xA8\\xB4eo\\xC2\\x01\\x1A\\x08\\x1F\\x12\\x0C2025.8.7.368\\x1D\\x00\\x00\\x00\\x00%\\xFC/\\x00\\x8E\\xC2\\x01\\x0F\\x08\\x08\\x12\\x017\\x1D\\xC0^Q\\xFD%;\\xCAI\\x1C\\xC2\\x01\\x19\\x08(\\x12\\x0B2025.7.24.0\\x1D\\x00\\x00\\x00\\x00%\tcq\\xBF\\xC2\\x01\\x0F\\x08B\\x12\\x013\\x1D\\x9E\\xAA\\x1F\\x83%\\xB6\\x9F\\xB0\\xE0\\xC2\\x01\\x12\\x08\n\\x12\\x049959\\x1D\\x00\\x00\\x00\\x00%\\xA4\\x07\\xC7b\\xC2\\x01\\x18\\x082\\x12\n"
		"1.3.36.141\\x1DF\\xB2\\xED\\xAE%\\xDB\\xED\\xA0\\x00\\xC2\\x01\\x1A\\x08)\\x12\\x0C120.0.6050.0\\x1D\\xA7b,\\xC5%|?'Y\\xC2\\x01\\x18\\x08?\\x12\n2025.8.8.1\\x1D\\x00\\x00\\x00\\x00%\\x99K\\xD8\\xA8\\xC2\\x01\\x12\\x083\\x12\\x043077\\x1D\\x00\\x00\\x00\\x00%o5\\xC7\\xF4\\xC2\\x01\\x10\\x08\\x02\\x12\\x0267\\x1D\\x85z\\xC9D%U\\xF4\\xBF\\xFA\\xC2\\x01\\x19\\x08>\\x12\\x0B2025.5.15.1\\x1D\\x00\\x00\\x00\\x00%v8\\x8D\\xE6\\xC2\\x01\\x1E\\x08/"
		"\\x12\\x101.0.7.1744928549\\x1D`\\xBAD\\xE4%\\x82\\xBB\\xB5\\xF5\\xC2\\x01\\x16\\x08\\x03\\x12\\x081.0.0.17\\x1D\\xC2\\xE38&%\\xDB\\xED\\xA0\\x00\\xC2\\x01\\x11\\x08\\x12\\x12\\x03530\\x1D\\x00\\x00\\x00\\x00%\\x11\\xAB\\x10\\xFB\\xC2\\x01\\x13\\x084\\x12\\x05140.2\\x1D\\x00\\x00\\x00\\x00%\\xA8\\xC7(\\x88\\xC2\\x01\\x18\\x08\\x1E\\x12\n1.0.2738.0\\x1D\\x9A\\xBA\\x00\\xC9%[\\x842\\x16\\xC2\\x01#\\x08\\x19\\x12\\x1520250716.785234264.14\\x1D\\x00\\x00\\x00\\x00%\\xBE.\\x05%\\xC2\\x01\\x19\\x08\r"
		"\\x12\\x0B4.10.2891.0\\x1D\\x00\\x00\\x00\\x00%\\x11\\x01\\xE4W\\xC2\\x01\\x0F\\x08\\x1B\\x12\\x013\\x1D\\xA4fVT%\\xE3\\xCA4\\xB6\\xCA\\x01 \\x08\\x04\\x10\\x05\\x18\\x01 \\x00(\\x000\\x008\\x00@\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\x88\\x01\\x00\\xCA\\x01\"\\x08\\x01\\x10\\x06\\x18\\x03 \\x04(\\x000\\x008\\x01@\\x01P\\x00X\\x00`\\x00h\\x03p\nx\\x00\\x80\\x01\\x00\\x88\\x01\\x00\\xCA\\x01 \\x08\\x01\\x10\\x05\\x18\\x03 \\x00"
		"(\\x000\\x008\\x00@\\x00P\\x00X\\x00`\\x00h\\x03x\\x00\\x80\\x01\\x00\\x88\\x01\\x00\\xCA\\x01 \\x08\\x01\\x10\\x06\\x18\\x03 \\x00(\\x000\\x008\\x01@\\x01P\\x00X\\x01`\\x00h\\x03x\\x00\\x80\\x01\\x00\\x88\\x01\\x00\\xCA\\x01 \\x08\\x01\\x10\\x01\\x18\\x03 \\x04(\\x000\\x008\\x01@\\x01P\\x00X\\x00`\\x00h\\x03x\\x00\\x80\\x01\\x00\\x88\\x01\\x00\\xCA\\x01 \\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00P\\x00X\\x00`\\x00h\\x00x\\x00\\x80\\x01\\x00\\x88\\x01\\x00\\xCA\\x01 "
		"\\x08\\x01\\x10\\x05\\x18\\x02 \\x00(\\x000\\x008\\x00@\\x00P\\x00X\\x00`\\x00h\\x02x\\x00\\x80\\x01\\x00\\x88\\x01\\x00\\xCA\\x01 \\x08\\x06\\x10\n\\x18\\x02 \\x00(\\x000\\x008\\x01@\\x01P\\x00X\\x01`\\x00h\\x02x\\x00\\x80\\x01\\x00\\x88\\x01\\x00\\xE2\\x01\\x1620250807-180039.874000\\xF8\\x01\\x91/"
		"\\x80\\x02\\xFF\\xFF\\xFF\\xFF\\xFF\\xFF\\xFF\\xFF\\xFF\\x01\\x88\\x02\\x01\\x92\\x02$ac1efd70-ce6d-4bad-ad15-7954e244cbdd\\xA8\\x02\\xC3\\x1B\\xF1\\x02\\xE9\\xA5\\x8A\\x8D\\xD4\\xF9\\x16\\xAF\\xFA\\x022\r\\x00XFI\\x12\\x0B7.85.4555.0\"\\x10SLB9670         2\\x0C2.0, 0, 1.382\r\tVM\\xC4\\xD3\\xE0\\x1D],\\x1A\\x02\\x10\\x012\\x0F\t_\\xFC\\xBB9\\xAF\\x97\\xD3\\x9A\\x10\\x01\\x1A\\x02\\x10\\x022\\x11\t\\x17\\xF9\\xCB\\xEA\\x16s\\xCD\\x8C\\x10\\x84\\x07\\x1A\\x03\\x10\\x85\\x07\\xE0\\x01\\xE9\""
		"\\xE8\\x01\\x9C\\x1F", 
		LAST);

	web_add_header("X-Chrome-UMA-Log-HMAC-SHA256", 
		"0lScKAY0T8Xa/h1Jc3ydUfYXb2swLkEekoQWwCYU9lY=");

	web_add_header("X-Chrome-UMA-Log-SHA1", 
		"34EB0DDD20D624D97B0FBEAF6BF396DE71928998");

	web_custom_request("v2_2", 
		"URL=https://clientservices.googleapis.com/uma/v2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/vnd.chrome.uma", 
		body_variable_1, 
		LAST);

	web_revert_auto_header("X-Chrome-UMA-ReportingInfo");

	web_add_header("X-Goog-Update-AppId", 
		"neifaoindggfcjicffkgpmnlppeffabd,ihnlcenocehgdaegdmhbidjhnhdchfmm,niikhdgajlphfehepabhhblakbdgeefj,gcmjkmgdlgnkkcocmoeiminaijmmjnii,obedbbhbpmojnkanicioggnmelmoomoc,lmelglejhemejginpboagddgdfbepgmp,oimompecagnajdejgnnjijobebaeigek,kiabhabjdbkjdpjbpigfodbdjmbglcoo,giekcmmlnklenlaomppkphknjmnnpneh,khaoiebndkojlmppeemjhbpbandiljpe,efniojlnjndmcbiieegkicadnoecjjef,llkgjffcdpffmhiakmfcdcblohccpfmo,laoigpblnllgcgjnjnllmfolckpjlhki,ggkkehgbnfjpeggfpleeakpidbkibbmn,jamhcnnkihinmdlkakkaopbjbbcngflc,"
		"mfhmdacoffpmifoibamicehhklffanao,pmagihnlncbcefglppponlgakiphldeh,mcfjlbnicoclaecapilmleaelokfnijm,jflookgnkcckhobaglndicnbbgbonegd,hajigopbbjhghbfimgkfmpenfkclmohk,ldfkbgjbencjpgjfleiooeldhjdapggh,ojhpjlocmbogdgmfpkhlaaeamibhnphh,jflhchccmppkfebkiaminageehmchikm,eeigpngbgcognadeebkilcpcaedhellh,hfnkpimlhhgieaddgfemjhofmfblmnib");

	web_add_header("X-Goog-Update-Interactivity", 
		"bg");

	web_add_header("X-Goog-Update-Updater", 
		"chrome-139.0.7258.66");

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=15:FntDM5kJyBvLypLbhHrAGcvqPEBKnjzZY2qRvev0xEc&cup2hreq=3ed5f1a6ae83f5ba2949300e28928c4482a8d158a63cccbabb479c4c66ed3d14", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,download,puff,run,xz,zucc\",\"apps\":[{\"appid\":\"neifaoindggfcjicffkgpmnlppeffabd\",\"brand\":\"GGLS\",\"cohort\":\"1:1299:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5954,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{763186bf-0f1f-4aa3-b674-382f227d6253}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"1.0.2738.0\"},{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GGLS\",\"cohort\""
		":\"1::\",\"enabled\":true,\"installdate\":5954,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{01bf6d74-64da-4fe3-b551-49dfa0e356fc}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"1.3.36.141\"},{\"appid\":\"niikhdgajlphfehepabhhblakbdgeefj\",\"brand\":\"GGLS\",\"cached_items\":[{\"sha256\":\"38c89b12bb20a8f2751c9c7cd2e31c173a47af08c115e1ecccc2f5151a2cf2c6\"}],\"cohort\":\"1:1uh3:\",\"cohortname\":\"Auto Main Cohort.\",\"enabled\":true,\"installdate\":6135,\"lang\":\"en-GB\",\"ping\":{\""
		"ping_freshness\":\"{0e80d41b-d3cb-4d66-8449-248acbf10cad}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"2025.6.16.0\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GGLS\",\"cached_items\":[{\"sha256\":\"15335e5e45db72828ff3226e84eccf2e71a4f7f51da7392fb2e3e24348ecff28\"}],\"cohort\":\"1:bm1:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":5954,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{c1eb9adf-d72e-47e4-a226-fd8090e92db0}\",\"rd\":6795},\"updatecheck\":{},\""
		"version\":\"9.58.0\"},{\"accept_locale\":\"ENGB500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"GGLS\",\"cached_items\":[{\"sha256\":\"f0dbba63ec90be3661a98d1f747295bc44697b89748c39d18133ca3206c780ec\"}],\"cohort\":\"1:s6f:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5954,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{bdb5bfb5-d5c7-45af-a86a-74db8fdc49f1}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"20250716.785234264.14\"},{\"appid\":\""
		"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"GGLS\",\"cached_items\":[{\"sha256\":\"7e1de38ac92f5806a80f9e2be8958f34347b46f145d9c0b1e69d82757c91768b\"}],\"cohort\":\"1:lwl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5954,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{b43cd001-5413-4466-a220-4b6191cdc5ea}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"530\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GGLS\",\"cohort\":\"1:2qw3:\",\"cohortname\":\"Auto\",\""
		"enabled\":true,\"installdate\":5954,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{fbdcfa47-44b1-477b-b08b-8d48ff777ecb}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"4.10.2891.0\"},{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"GGLS\",\"cached_items\":[{\"sha256\":\"953969d8ce784f0b3c94317f147792886bc5d9f6423ddf8617961238219a4492\"}],\"cohort\":\"1:v3l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6071,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\""
		"{3787bb2d-c42f-4f63-9813-6ffd9df88f50}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"2025.5.15.1\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GGLS\",\"cohort\":\"1:j5l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5954,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{72182579-6150-42f1-810f-5720ee1a33b8}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GGLS\",\"cohort\":\"1:cux:\",\"cohortname\":\""
		"Auto\",\"enabled\":true,\"installdate\":5954,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{73766247-bb36-42cb-a8ca-b3562e935ae3}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"67\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"GGLS\",\"cached_items\":[{\"sha256\":\"aef3e6a6cd21fb4afbdf73cbd868c18fdda50e4732e560006690283e9c893339\"}],\"cohort\":\"1:18ql:\",\"cohortname\":\"Auto Stage3\",\"enabled\":true,\"installdate\":5954,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\""
		"{ff03ec74-2f59-4a40-a405-2663ce385744}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"1390\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5954,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{f6d0149a-b635-4d2b-93f3-d8f6bd0394a8}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"1.0.0.17\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"GGLS\",\"cohort\":\"1:10zr:\",\"cohortname\":\"Auto\",\"enabled\":true,\""
		"installdate\":5954,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{b4224de1-ff4d-4f46-8be0-3399631d7276}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"1.0.7.1744928549\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"GGLS\",\"cached_items\":[{\"sha256\":\"451dcf5c7d23877d6c499ec9f2441573b49a2df283fdfcd14fdbac78381e6f8a\"}],\"cohort\":\"1:ut9/1a0f:\",\"cohortname\":\"M108 and Above\",\"enabled\":true,\"installdate\":5954,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\""
		"{868531b7-cbe3-4a14-90b1-9d72691123a9}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"2025.8.7.368\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"GGLS\",\"cohort\":\"1:wvr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5954,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{4859a410-78ef-4de8-bb57-63d8e32403e0}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"120.0.6050.0\"},{\"appid\":\"mfhmdacoffpmifoibamicehhklffanao\",\"brand\":\"GGLS\",\"cached_items\":[{\"sha256"
		"\":\"fd850c67c65c723d3e5778cb125e383eae57c8b1cc3d76f46f33990ad1a482da\"}],\"cohort\":\"1:1ge3:36c3@0.1\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6461,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{2507e9f1-fd13-492d-8b45-acdb82fb800c}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"140.2\"},{\"appid\":\"pmagihnlncbcefglppponlgakiphldeh\",\"brand\":\"GGLS\",\"cohort\":\"1:2ntr:\",\"cohortname\":\"General Release\",\"enabled\":true,\"installdate\":6639,\"lang\":\"en-GB\",\""
		"ping\":{\"ping_freshness\":\"{f14d40c0-ab10-4d74-8653-3660d3b186fc}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"2024.10.17.0\"},{\"appid\":\"mcfjlbnicoclaecapilmleaelokfnijm\",\"brand\":\"GGLS\",\"cohort\":\"1:2ql3:\",\"cohortname\":\"Initial upload\",\"enabled\":true,\"installdate\":6639,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{15cc21d1-d338-4155-884a-bb84a340c719}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"2024.11.26.0\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\""
		"brand\":\"GGLS\",\"cached_items\":[{\"sha256\":\"d039e17b9495e81db53fd3a16d7c3c7c87ed51c9829c8fe3b2ca5cad2700bef5\"}],\"cohort\":\"1:s7x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5954,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{913a5f7e-08c5-4ef9-8722-a05f10af2683}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"3077\"},{\"appid\":\"hajigopbbjhghbfimgkfmpenfkclmohk\",\"brand\":\"GGLS\",\"cohort\":\"1:2tdl:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6624,"
		"\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{5d0d447a-b39e-4f1f-88a8-31b6f4523f47}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"ldfkbgjbencjpgjfleiooeldhjdapggh\",\"brand\":\"GGLS\",\"cohort\":\"1:2v8l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6672,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{76913ce4-509e-4db2-9801-15e95721adf2}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"2025.2.18.1\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand"
		"\":\"GGLS\",\"cohort\":\"1:w0x:\",\"cohortname\":\"All users\",\"enabled\":true,\"installdate\":5954,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{b6e5d404-f583-4435-a5de-4bad2cd390b1}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"jflhchccmppkfebkiaminageehmchikm\",\"brand\":\"GGLS\",\"cached_items\":[{\"sha256\":\"959ac4f4791f239d5c5d8f5c4536d1acf626789894faeff77bafabac5bfc274d\"}],\"cohort\":\"1:26yf:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6154,\""
		"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{ab61739e-b1dc-4ded-aef0-c378ee0131f1}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"2025.8.8.1\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"GGLS\",\"cached_items\":[{\"sha256\":\"4497d8060d0e53c12b4403aa9ebe7e827d4880bae3f4139a26a4feb7ed64c4a2\"}],\"cohort\":\"1:w59:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5954,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{37886cb0-46b9-42c5-bf7b-a70b57c33b87}\",\"rd\""
		":6795},\"updatecheck\":{},\"version\":\"2025.6.13.84507\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GGLS\",\"cached_items\":[{\"sha256\":\"0478f668f580e2b20ce7fe53f2714d0295311991625a1137907df639aa1190dd\"}],\"cohort\":\"1:287f:\",\"cohortname\":\"Auto full\",\"enabled\":true,\"installdate\":5954,\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{ae0ecb17-5227-4f6d-8bd8-eb698b03ca0c}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"9959\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\""
		"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":16,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.26100.4770\"},\"prodversion\":\"139.0.7258.66\",\"protocol\":\"4.0\",\"requestid\":\"{e7045897-b8d9-4a62-a6a7-c20e93f31c3c}\",\"sessionid\":\"{726d24e8-8ac0-4835-a73b-01e4beac3658}\",\"updaters\":{\"autoupdatecheckenabled\":true,\""
		"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"ChromiumUpdater\",\"updatepolicy\":-1,\"version\":\"140.0.7273.0\"},\"updaterversion\":\"139.0.7258.66\"}}", 
		LAST);

	web_add_header("X-Chrome-UMA-Log-HMAC-SHA256", 
		"5q/s3+a7IEIYs/f6dwYp0uf7fFdewYDjZMTQ1sHF17M=");

	web_add_header("X-Chrome-UMA-Log-SHA1", 
		"227DA49CE1EC5B3A7D759864CC9D79A031FB327D");

	web_add_header("X-Chrome-UMA-ReportingInfo", 
		"CAEQyAEYACAB");

	web_custom_request("v2_3", 
		"URL=https://clientservices.googleapis.com/uma/v2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/vnd.chrome.uma", 
		body_variable_2, 
		LAST);

	web_revert_auto_header("Sec-Fetch-Dest");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_revert_auto_header("Sec-Fetch-Site");

	lr_think_time(19);

	web_custom_request("upload", 
		"URL=https://beacons.gcp.gvt2.com/domainreliability/upload", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/javascript", 
		"Referer=", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"entries\":[{\"http_response_code\":200,\"network_changed\":false,\"protocol\":\"HTTPS\",\"request_age_ms\":77834,\"request_elapsed_ms\":5696,\"sample_rate\":0.05,\"server_ip\":\"192.168.56.1:8888\",\"status\":\"ok\",\"url\":\"https://fonts.googleapis.com/\",\"was_proxied\":true}],\"reporter\":\"chrome\"}", 
		EXTRARES, 
		"Url=https://fonts.gstatic.com/s/opensans/v43/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTS-muw.woff2", "Referer=https://fonts.googleapis.com/", ENDITEM, 
		"Url=https://cdn.jsdelivr.net/gh/aspectran/aspectran-assets/app/webroot/assets/foundation@6.9.0/fonts/iconfont.woff", "Referer=https://cdn.jsdelivr.net/gh/aspectran/aspectran-assets/app/webroot/assets/foundation@6.9.0/css/aspectran.css", ENDITEM, 
		"Url=https://cdn.jsdelivr.net/gh/aspectran/aspectran-assets/app/webroot/assets/foundation@6.9.0/fonts/foundation-icons.woff", "Referer=https://cdn.jsdelivr.net/gh/aspectran/aspectran-assets/app/webroot/assets/foundation@6.9.0/css/aspectran.css", ENDITEM, 
		"Url=https://content-autofill.googleapis.com/v1/pages/ChRDaHJvbWUvMTM5LjAuNzI1OC42NhIZCRyrFQOdoimJEgUNAo_7aCERtX5rZzBL7BIZCRk321u0-HwBEgUNAo_7aCERtX5rZzBL7A==?alt=proto", "Referer=", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_header("X-Goog-Update-AppId", 
		"efaidnbmnnnibpcajpcglclefindmkaj,ghbmnnjooekpmoecnnnilnnbdlolhkhi,mbopgmdnpcbohhpnfglgohlbhfongabi,nmmhkkegccagdldgiimedpiccmgmieda");

	web_add_header("X-Goog-Update-Interactivity", 
		"bg");

	web_add_header("X-Goog-Update-Updater", 
		"chromecrx-139.0.7258.66");

	web_custom_request("json_2", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=15:iktDMhFq5B7ghnD4yvxLsyaVvBpkzA304vMY2KN4-Bc&cup2hreq=78308beea0525fc0129f0ca12ded534e26fea08b48edd6df1da28aa154ba0b41", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chromecrx\",\"acceptformat\":\"crx3,download,puff,run,xz,zucc\",\"apps\":[{\"appid\":\"efaidnbmnnnibpcajpcglclefindmkaj\",\"cached_items\":[{\"sha256\":\"a2a74e01cdb559a8b2a6849dfb8dd3c3cea22325ba60a7f0d4745263bb09c28d\"}],\"cohort\":\"1::\",\"disabled\":[{\"reason\":8192}],\"enabled\":false,\"installdate\":6716,\"installedby\":\"external\",\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{564a6f0e-e44d-42e5-b2a1-3ba77d22bf89}\",\"rd\":6795},\""
		"updatecheck\":{},\"version\":\"25.7.2.1\"},{\"appid\":\"ghbmnnjooekpmoecnnnilnnbdlolhkhi\",\"cached_items\":[{\"sha256\":\"a09c3dd83a50f1a9e3d59e8dfc347717e86fae2434f239637afd4037511b26d2\"}],\"cohort\":\"1::\",\"enabled\":true,\"installdate\":6716,\"installedby\":\"external\",\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{d12e976e-2a83-434c-befe-dcd319861170}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"1.94.1\"},{\"appid\":\"mbopgmdnpcbohhpnfglgohlbhfongabi\",\"cached_items\":[{\"sha256\""
		":\"1d4f3ce55f05f1f374d85068daa03ca91643c805f5ae4fa7d89cd0ba33a73b99\"}],\"cohort\":\"1::\",\"enabled\":true,\"installdate\":6787,\"installedby\":\"internal\",\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\"{4aafa805-a29e-47b9-ad63-28f59b931844}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"6.6.7\"},{\"appid\":\"nmmhkkegccagdldgiimedpiccmgmieda\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":6716,\"installedby\":\"other\",\"lang\":\"en-GB\",\"ping\":{\"ping_freshness\":\""
		"{2c65c88e-3a70-4346-8bc3-da5ca48e916c}\",\"rd\":6795},\"updatecheck\":{},\"version\":\"1.0.0.6\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":16,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.26100.4770\"},\"prodversion\":\"139.0.7258.66\",\"protocol\":\"4.0\",\"requestid\":\""
		"{2d99d03b-39c4-4277-ae84-540188906d59}\",\"sessionid\":\"{48199531-4266-47a2-857b-49e280b9aa8f}\",\"updaterversion\":\"139.0.7258.66\"}}", 
		LAST);

	lr_end_transaction("Launch",LR_AUTO);

	web_submit_data("register3", 
		"Action=https://android.clients.google.com/c2dm/register3", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=app", "Value=com.google.android.gms", ENDITEM, 
		"Name=device", "Value=4902502336878990234", ENDITEM, 
		"Name=sender", "Value=745476177629", ENDITEM, 
		LAST);

	web_add_header("X-Chrome-UMA-Log-HMAC-SHA256", 
		"uF1toB0dspELHKc8RRu3R2Rdo6O7OFrRI4vPX8QEd60=");

	web_add_header("X-Chrome-UMA-Log-SHA1", 
		"CE9C3CD2820502CE9F29D9E7C684E49BF28B78EC");

	web_add_header("X-Chrome-UMA-ReportingInfo", 
		"CAEQyAEYACAB");

	web_custom_request("v2_4", 
		"URL=https://clientservices.googleapis.com/uma/v2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t13.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/vnd.chrome.uma", 
		body_variable_3, 
		LAST);

	web_add_header("X-Client-Data", 
		"CIi2yQEIo7bJAQipncoBCKOIywEIlaHLAQiko8sBCIWgzQEImvzOAQi6/c4BCOuAzwEIlIHPAQiEhM8BGOHizgE=");

	web_custom_request("v1_GetModels_2", 
		"URL=https://optimizationguide-pa.googleapis.com/v1_GetModels?key=AIzaSyA2KlwBX3mkFo30om9LUFYQhpqLoa_BNhE", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/x-protobuf", 
		"Referer=", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=application/x-protobuf", 
		"BodyBinary=\n\n\\x08\\x02\\x10\\xC6\\xB2\\xE1\\xA0\\x06 \\x14\nt\\x08\t\\x10\\x8B\\xB8\\x9D\\xC0\\x06 \\x142h\natype.googleapis.com/google.privacy.webpermissionpredictions.v1.WebPermissionPredictionsClientInfo\\x12\\x03\\x08\\x8B\\x01\n\n\\x08\r\\x10\\xF1\\xE9\\x9C\\x9E\\x06 \\x14\ng\\x08\\x0F\\x10\\x05 \\x142_\nWtype.googleapis.com/google.internal.chrome.optimizationguide.v1.PageTopicsModelMetadata\\x12\\x04\\x08\\x020\\x02\ng\\x08\\x10 \\x142a\nYtype.googleapis.com/"
		"google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\nt\\x08\\x14\\x10\\xEB\\xAC\\x9D\\xC0\\x06 \\x142h\natype.googleapis.com/google.privacy.webpermissionpredictions.v1.WebPermissionPredictionsClientInfo\\x12\\x03\\x08\\x8B\\x01\ng\\x08\\x15 \\x142a\nYtype.googleapis.com/google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\ng\\x08\\x17 \\x142a\nYtype.googleapis.com/"
		"google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\n\n\\x08\\x18\\x10\\xF4\\xC3\\x90\\xB8\\x06 \\x14\n\n\\x08\\x19\\x10\\x84\\xD1\\xFE\\xC3\\x06 \\x14\nr\\x08\\x1A\\x10\\xA6\\x80\\xEC\\xA8\\x06 \\x142f\n`type.googleapis.com/google.internal.chrome.optimizationguide.v1.AutocompleteScoringModelMetadata\\x12\\x02\\x10\\x02\ng\\x08\\x1B \\x142a\nYtype.googleapis.com/"
		"google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\n\n\\x08(\\x10\\xD4\\xFE\\x98\\xC1\\x06 \\x14\nn\\x08-\\x10\\x9B\\xE2\\xC0\\xE5\\x80\\x07 \\x142a\nYtype.googleapis.com/google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\ng\\x08. \\x142a\nYtype.googleapis.com/google.internal.chrome.optimizationguide.v1.SegmentationModelMetadata\\x12\\x04J\\x02\\x10\\x03\n\\x84\\x01\\x087\\x10\\xCC\\xCE\\xF9\\xC3\\x06 "
		"\\x142x\nYtype.googleapis.com/google.internal.chrome.optimizationguide.v1.OnDeviceBaseModelMetadata\\x12\\x1B\n\\x06v3Nano\\x12\\x0F2025.06.30.1229\\x18\\x02\\x18\\x06*\\x05en-GB2\\x02\\x08\\x06", 
		LAST);

	lr_think_time(18);

	lr_start_transaction("Signup");

	web_custom_request("google-ohttp-relay-safebrowsing.fastly-edge.com", 
		"URL=https://google-ohttp-relay-safebrowsing.fastly-edge.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=message/ohttp-res", 
		"Referer=", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=message/ohttp-req", 
		"BodyBinary=\\xD8\\x00 \\x00\\x01\\x00\\x02\\x95g\\x9D\\xC5\\xEA4\\xD7\\xA2>\\xA8d\\x18`nDAYi\\x8B\\x9F\\xCB\\xBE\\xD5/\\xCE.\\x1A\\x0Co\\x19\\x9C5\\xC3\\xBB\\x07en\\xA4&\\xD1!9\\x1C\\x0C\\x0C\\xCCy\\xF5\\x0F?\\xAF\\xE1\\xFA;H\\x0C\\xB2I!\\x175\\x97\\x18/\\x8E\\x87\\x11+\\xE2\\x9E\\xE0\\xC2q\\xD4|\\x1AG\\xB6\t\\x06\\x195/z;\\x8C\\xC3\\xA6\\xE5\\xEBG\\x94\\xA2\\xE6\\x9F\\x98\\x05\\xAD\\xC7\\x06Y\\x9Fz2\\xEE\\xD2s\\xAD\\xD3r\\x8E~\\xB4\\x8A\\x05\\xCDD\\xC1\\xE8\\xDFe\\xF3gEm\"1i"
		"!\\x10R\\x98\\x92\\x15\\x810\\x99\\xC9g\\xA1\t\\xEE\\\\N%\\xBB\\xA8\\xC9\\x98\\xCB{\\xAD\\xEEH)\\xA4\\xA0E\\x7F\\x8F\\xC4f\\x8E\\xB5\\x0F\\x11\\xDA\\xC8`o\\x02n(\\xE3\\x9B\\x8E\\xBE\\xD8\\x99\\x01\\xD4k\\xA7\\xEC\\xAA\\xB2~&S\"\\xCB\\x05%_\\xF7%hub\\xB7\\xC1R\\x96#Up1\\xD2\\xC3\\x18\\x94\\xDBa}\\xB9\\xB3\\xF3\\xE6\\xB8Y\\xC3)\\x19\\x87*\\xF6\\x07BR \\xC5\\x19\\xB8\\\\\\xBEJ\\xBDB\\x11nL/t|\\x80\\xCD\\xD2\\x1A\\xD9\t\\xC2%\\x86\\x9E\\xFD\\xC6\\x945\\x15\r\\xFD;"
		"\\x04\\x1Edxr\\xE7\\xD82\\x9F\\xCE\\xBA\\xFC\\xF8", 
		LAST);

	web_submit_data("register3_2", 
		"Action=https://android.clients.google.com/c2dm/register3", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=app", "Value=com.google.android.gms", ENDITEM, 
		"Name=device", "Value=4902502336878990234", ENDITEM, 
		"Name=sender", "Value=745476177629", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\"Not;A=Brand\";v=\"99\", \"Google Chrome\";v=\"139\", \"Chromium\";v=\"139\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_url("newAccountForm", 
		"URL=https://jpetstore.aspectran.com/account/newAccountForm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../cdn-cgi/speculation", ENDITEM, 
		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates_fetch?$req="
		"Ch0KDGdvb2dsZWNocm9tZRINMTM5LjAuNzI1OC42NhopCAUQARobCg0IBRAGGAEiAzAwMTABEOS9HBoCGAfMwntAIgQgASACKAEaKAgQEAEaGgoNCBAQBhgBIgMwMDEwARDlMxoCGAdSY89pIgQgASACKAEaKQgBEAEaGwoNCAEQBhgBIgMwMDEwARCl5REaAhgHKH8e3SIEIAEgAigBGikIAxABGhsKDQgDEAYYASIDMDAxMAEQid0RGgIYB-tyQXQiBCABIAIoARopCA4QARobCg0IDhAGGAEiAzAwMTABEI3xBxoCGAfK3W2CIgQgASACKAEaKQgHEAEaGwoNCAcQBhgBIgMwMDEwARCmjhIaAhgH7kSXwSIEIAEgAigBGigIARAIGhoKDQgBEAgYASIDMDAxMAQQvj0aAhgH0M6H1SIEIAEgAigEGikIDxABGhsKDQgPEAYYASIDMDAxMAEQ2qIGGgIYB6vHJJkiBCABIAIoARonCA"
		"kQARoZCg0ICRAGGAEiAzAwMTABECMaAhgH9wNdlCIEIAEgAigBGigICBABGhoKDQgIEAYYASIDMDAxMAEQ5xkaAhgHV0-KAyIEIAEgAigBGikIDRABGhsKDQgNEAYYASIDMDAxMAEQ1c4CGgIYB0h4pGEiBCABIAIoASICCAE=&$ct=application/x-protobuf&key=AIzaSyA2KlwBX3mkFo30om9LUFYQhpqLoa_BNhE", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(20);

	web_submit_data("register3_3", 
		"Action=https://android.clients.google.com/c2dm/register3", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=app", "Value=com.google.android.gms", ENDITEM, 
		"Name=device", "Value=4902502336878990234", ENDITEM, 
		"Name=sender", "Value=745476177629", ENDITEM, 
		LAST);

	web_revert_auto_header("Sec-Fetch-Dest");

	web_revert_auto_header("Sec-Fetch-Mode");

	web_revert_auto_header("Sec-Fetch-Site");

	web_custom_request("upload_2", 
		"URL=https://beacons.gcp.gvt2.com/domainreliability/upload", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/javascript", 
		"Referer=", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"entries\":[{\"failure_data\":{\"custom_error\":\"net::ERR_ABORTED\"},\"http_response_code\":200,\"network_changed\":false,\"protocol\":\"HTTP\",\"request_age_ms\":77966,\"request_elapsed_ms\":1783,\"sample_rate\":1.0,\"server_ip\":\"\",\"status\":\"aborted\",\"url\":\"https://beacons.gcp.gvt2.com/domainreliability/upload\",\"was_proxied\":true}],\"reporter\":\"chrome\"}", 
		LAST);

	lr_think_time(106);

	web_submit_data("register3_4", 
		"Action=https://android.clients.google.com/c2dm/register3", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=app", "Value=com.google.android.gms", ENDITEM, 
		"Name=device", "Value=4902502336878990234", ENDITEM, 
		"Name=sender", "Value=745476177629", ENDITEM, 
		LAST);

	return 0;
}